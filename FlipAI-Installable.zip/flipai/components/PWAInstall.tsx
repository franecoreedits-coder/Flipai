'use client';
import { useEffect, useState } from 'react';
import { Download, Smartphone, Share, X } from 'lucide-react';

type InstallPrompt = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }> };
export default function PWAInstall() {
  const [prompt, setPrompt] = useState<InstallPrompt | null>(null);
  const [ios, setIos] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  useEffect(() => {
    setIos(/iphone|ipad|ipod/i.test(navigator.userAgent) && !(window as any).matchMedia?.('(display-mode: standalone)').matches);
    setInstalled(window.matchMedia('(display-mode: standalone)').matches);
    const handlePrompt = (event: Event) => { event.preventDefault(); setPrompt(event as InstallPrompt); };
    const handleInstalled = () => { setInstalled(true); setPrompt(null); };
    window.addEventListener('beforeinstallprompt', handlePrompt);
    window.addEventListener('appinstalled', handleInstalled);
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
    return () => { window.removeEventListener('beforeinstallprompt', handlePrompt); window.removeEventListener('appinstalled', handleInstalled); };
  }, []);
  if (installed || dismissed) return null;
  return <section className="panel settings-panel pwa-install-card">
    <div className="settings-heading"><Smartphone size={18}/><h3>Install FlipAI</h3></div>
    <p className="settings-description">Add FlipAI to your home screen for a full-screen app experience and quick access in the shop.</p>
    {prompt ? <button className="btn-primary" onClick={async () => { await prompt.prompt(); const result = await prompt.userChoice; if(result.outcome === 'accepted') setInstalled(true); setPrompt(null); }}><Download size={15}/> Install app</button>
      : ios ? <p className="settings-description install-tip"><Share size={15}/> On iPhone/iPad: tap <b>Share</b>, then <b>Add to Home Screen</b>.</p>
      : <p className="settings-description install-tip">Install option appears in your browser menu: <b>Install app</b> or <b>Add to Home Screen</b>. (Available after the site is deployed over HTTPS.)</p>}
    <button className="install-dismiss" onClick={() => setDismissed(true)} aria-label="Dismiss install card"><X size={14}/></button>
  </section>;
}
