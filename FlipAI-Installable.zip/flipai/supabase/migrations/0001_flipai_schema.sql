-- Apply in Supabase SQL editor. Tables use per-user RLS, no public write policies.
create extension if not exists pgcrypto;
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 email text, display_name text, avatar_url text,
 experience_level text check (experience_level in ('beginner','casual','experienced','professional')),
 preferred_categories text[] not null default '{}', monthly_profit_goal numeric check(monthly_profit_goal>=0),
 currency text not null default 'EUR', created_at timestamptz not null default now()
);
create table public.scans (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 image_urls text[] not null default '{}', identified_name text, brand text, model text, category text,
 identification_confidence integer check(identification_confidence between 0 and 100),
 purchase_price numeric not null default 0 check(purchase_price>=0), estimated_low numeric, estimated_median numeric, estimated_high numeric,
 market_data_source text not null default 'AI estimate — not verified', market_data_timestamp timestamptz,
 flip_score integer check(flip_score between 0 and 100), recommendation text check(recommendation in ('BUY','MAYBE','SKIP')),
 analysis_json jsonb not null default '{}', created_at timestamptz not null default now()
);
create table public.inventory (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade, scan_id uuid references public.scans(id) on delete set null,
 name text not null, brand text, model text, category text, image_urls text[] not null default '{}',
 purchase_price numeric not null default 0 check(purchase_price>=0), purchase_date date, additional_costs numeric not null default 0 check(additional_costs>=0), estimated_value numeric, listing_price numeric, listing_url text, marketplace text,
 status text not null default 'planning' check(status in ('planning','purchased','preparing','listed','sold','returned','damaged')),
 sale_price numeric, sale_date date, actual_fees numeric not null default 0, shipping_cost numeric not null default 0, realized_profit numeric, notes text,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.watchlist (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 name text not null, target_buy_price numeric, expected_resale numeric, target_profit numeric, url text, notes text, created_at timestamptz not null default now()
);
create table public.subscriptions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null unique references auth.users(id) on delete cascade,
 stripe_customer_id text unique, stripe_subscription_id text unique, plan text not null default 'free', status text not null default 'inactive', current_period_end timestamptz, created_at timestamptz not null default now()
);
create table public.notifications (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 type text not null, title text not null, body text not null, read boolean not null default false, created_at timestamptz not null default now()
);
create table public.scan_usage (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 scan_date date not null default current_date, scan_count integer not null default 0 check(scan_count>=0), unique(user_id,scan_date)
);
create index scans_user_created_idx on public.scans(user_id,created_at desc);
create index inventory_user_status_idx on public.inventory(user_id,status);
create index inventory_user_created_idx on public.inventory(user_id,created_at desc);
create index watchlist_user_created_idx on public.watchlist(user_id,created_at desc);
create index notifications_user_unread_idx on public.notifications(user_id,read,created_at desc);
-- Updated-at helper
create or replace function public.set_updated_at() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
create trigger inventory_updated_at before update on public.inventory for each row execute function public.set_updated_at();
-- RLS: user can only access own records. Service-role operations should remain server-side.
do $$ declare t text; begin foreach t in array['scans','inventory','watchlist','subscriptions','notifications','scan_usage'] loop execute format('alter table public.%I enable row level security',t); execute format('create policy %I_select_own on public.%I for select to authenticated using (auth.uid()=user_id)',t,t); execute format('create policy %I_insert_own on public.%I for insert to authenticated with check (auth.uid()=user_id)',t,t); execute format('create policy %I_update_own on public.%I for update to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id)',t,t); execute format('create policy %I_delete_own on public.%I for delete to authenticated using (auth.uid()=user_id)',t,t); end loop; end $$;
-- profiles.id maps auth.uid(); profile table has no user_id column, so replace generated policies.
alter table public.profiles enable row level security;
drop policy if exists profiles_select_own on public.profiles; drop policy if exists profiles_insert_own on public.profiles; drop policy if exists profiles_update_own on public.profiles; drop policy if exists profiles_delete_own on public.profiles;
create policy profiles_select_own on public.profiles for select to authenticated using (auth.uid()=id);
create policy profiles_insert_own on public.profiles for insert to authenticated with check (auth.uid()=id);
create policy profiles_update_own on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);
create policy profiles_delete_own on public.profiles for delete to authenticated using (auth.uid()=id);
-- Keep plan entitlements and daily usage immutable to regular users.
drop policy if exists subscriptions_insert_own on public.subscriptions; drop policy if exists subscriptions_update_own on public.subscriptions; drop policy if exists subscriptions_delete_own on public.subscriptions;
drop policy if exists scan_usage_insert_own on public.scan_usage; drop policy if exists scan_usage_update_own on public.scan_usage; drop policy if exists scan_usage_delete_own on public.scan_usage;
-- Profile row is provisioned automatically after Supabase signup.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,email,display_name) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'full_name','')) on conflict(id) do nothing; return new; end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
