# FlipAI — resale intelligence MVP

Mobile-first Next.js App Router/TypeScript build for **Spot it. Scan it. Flip it.**

## What is working in this codebase
- Dark/lime branded dashboard, responsive desktop sidebar and mobile bottom nav.
- Landing/demo marketing page (`/welcome`), optional onboarding (`/onboarding`), Supabase email/password + Google OAuth sign-in form (`/login`).
- Photo scanner: 1–4 JPG/PNG/WEBP photos, max 8 MB each; seller asking price, currency, condition, location, notes.
- Server-side OpenAI Vision integration (`/api/analyze`) with validated JSON output, basic per-process throttling, clear missing-key errors, and an explicitly opted-in Demo Mode. Demo data is labeled.
- Editable profit calculator (sale price, fees, shipping, repairs, other costs), 3 resale scenarios, flip score and BUY/MAYBE/SKIP recommendation.
- Local scan history, inventory from saved scans, manual watchlist, analytics from entered inventory/sale figures, CSV inventory export and JSON local data export.
- Supabase schema migration with ownership RLS, indexes, profile signup trigger, and protected subscription/scan-usage writes.
- Stripe monthly Checkout endpoint scaffolding for Pro/Elite; price IDs are environment-configured.

## Important MVP limitations — not production-ready yet
- Auth is implemented as a Supabase client UI, but app pages/API are **not protected by auth middleware**, and inventory/scans are currently browser `localStorage`, not cloud persisted.
- The Stripe webhook verifies signatures but does not yet persist subscription events; billing portal, annual prices, trial support, full gating, usage enforcement and customer lifecycle handling are unfinished. Do not enable paid launch yet.
- The current rate limiter is in-memory and per process. Replace it with Redis/Upstash or another shared store for production.
- Market estimates are OpenAI model estimates, not verified sold comps. There are no live eBay/StockX/etc market connectors, listing publication, or automatic watchlist price monitoring.
- Scan results and saved inventory are device-local. Data exports and clear-data controls operate on local browser data.
- Crop/rotate editing, full camera UX, haptics, notifications, realtime sync, account deletion workflows, language switching and theme switching are not included yet.
- Analytics charts currently reflect saved sold items (not a full date-filtered trend engine). The dashboard uses local saved inventory for realized profit, sold count, inventory upside, and scan counts; its historical chart remains a simplified view.
- OpenAI estimates are not financial advice; inspect items, verify authenticity and compare recent sold listings before buying.

## Local setup
1. Install Node.js 20+ and npm.
2. Copy `.env.example` to `.env.local` and fill values.
3. Install packages: `npm install`
4. Start dev server: `npm run dev`
5. Open `http://localhost:3000`; `/welcome` is the marketing page, `/` is the app dashboard.

### Environment variables
- `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Supabase URL and anon key (browser-safe only).
- `SUPABASE_SERVICE_ROLE_KEY`: reserved for server-only database jobs; never expose it in browser code.
- `OPENAI_API_KEY`: server-only AI scan API key. Without it, scanner returns a setup error unless Demo Mode is explicitly selected.
- `OPENAI_MODEL`: optional vision-capable model name, defaults to `gpt-4o-mini`.
- `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRO_MONTHLY_PRICE_ID`, `STRIPE_ELITE_MONTHLY_PRICE_ID`: Stripe secrets and configured recurring price IDs.
- `NEXT_PUBLIC_APP_URL`: app base URL for Stripe redirects.

## Supabase setup
1. Create a Supabase project.
2. Run `supabase/migrations/0001_flipai_schema.sql` in the SQL editor.
3. Enable email auth and configure email verification.
4. Enable Google OAuth, add OAuth provider credentials and allowed redirect URLs.
5. Set env variables locally and in deployment.
6. Before production, audit RLS policies and implement server-side session checks for every private page/API. This MVP does not currently use the service-role key or persist app records to Supabase.


## Stripe setup (test mode first)
1. Create monthly recurring prices: Pro €9.99 and Elite €19.99.
2. Add price IDs and secret key to `.env.local`.
3. Set webhook endpoint to `/api/stripe/webhook`, include at minimum the subscription and checkout lifecycle events you need, and set webhook signing secret.
4. Complete webhook persistence, customer portal and entitlement enforcement before a real subscription launch. Current webhook only validates and acknowledges signed events.

## Test checklist
- Scan with API key, then scan in explicitly enabled Demo Mode without a key.
- Confirm missing key without Demo Mode is an honest setup error.
- Try invalid/large file types and negative prices.
- Change every calculator field and check net profit and ROI.
- Save scan; refresh and check dashboard history persistence.
- Add scan to inventory, search/filter, mark sold with entered values.
- Add/delete watchlist entries and test data export/clear.
- Run on narrow mobile width and verify bottom navigation.
- Configure Supabase/Stripe in test projects only, and validate authentication, RLS, webhook idempotency and checkout lifecycle before release.
