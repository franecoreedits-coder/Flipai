import './globals.css';
import type { Metadata } from 'next';
import PWAInstall from '@/components/PWAInstall';
export const metadata: Metadata = { title: 'FlipAI — Spot it. Scan it. Flip it.', description: 'AI-powered resale decision assistant.', manifest: '/manifest.json', appleWebApp: { capable: true, statusBarStyle: 'black-translucent', title: 'FlipAI' }, icons: { icon: [{ url: '/icons/flipai-192.png', sizes: '192x192', type: 'image/png' }, { url: '/icons/flipai-512.png', sizes: '512x512', type: 'image/png' }], apple: [{ url: '/icons/flipai-192.png' }] }, themeColor: '#0B0D0F' };
export default function RootLayout({ children }: { children: React.ReactNode }) { return <html lang="en"><body>{children}<PWAInstall /></body></html>; }
