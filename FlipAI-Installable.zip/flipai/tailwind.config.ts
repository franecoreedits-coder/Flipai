import type { Config } from 'tailwindcss';
const config: Config = { darkMode: ['class'], content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'], theme: { extend: { colors: { ink: '#0B0D0F', panel: '#15191D', lime: '#B7F34A' }, boxShadow: { lime: '0 0 24px rgba(183,243,74,.16)' } } }, plugins: [] };
export default config;
